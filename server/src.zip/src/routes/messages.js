import { Router } from "express";
import { z } from "zod";
import { query } from "../db.js";
import { requireAuth } from "../middleware/auth.js";
import { emitPrivateChatMessage, emitPublicChatMessage } from "../realtime.js";

const router = Router();

const messageSchema = z.object({
  recipient: z.string().max(64).nullable().optional(),
  content: z.string().min(1).max(500),
});

router.get("/feed", async (_req, res) => {
  try {
    const result = await query(
      `SELECT id, sender, recipient, content, created_at
       FROM messages
       WHERE recipient IS NULL
       ORDER BY created_at DESC
       LIMIT 100`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load feed" });
  }
});

router.get("/dm/:username", requireAuth, async (req, res) => {
  const { username } = req.params;
  try {
    const result = await query(
      `SELECT id, sender, recipient, content, created_at
       FROM messages
       WHERE (sender = $1 AND recipient = $2)
          OR (sender = $2 AND recipient = $1)
       ORDER BY created_at ASC
       LIMIT 200`,
      [req.user.username, username]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load messages" });
  }
});

router.get("/dm", requireAuth, async (req, res) => {
  try {
    const result = await query(
      `SELECT id, sender, recipient, content, created_at
         FROM messages
        WHERE sender = $1 OR recipient = $1
        ORDER BY created_at ASC
        LIMIT 400`,
      [req.user.username]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load conversations" });
  }
});

router.post("/send", requireAuth, async (req, res) => {
  const parse = messageSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: parse.error.flatten().fieldErrors });
  }

  const { recipient = null, content } = parse.data;
  try {
    const result = await query(
      `INSERT INTO messages (sender, recipient, content)
       VALUES ($1, $2, $3)
       RETURNING id, sender, recipient, content, created_at`,
      [req.user.username, recipient, content]
    );
    const savedMessage = result.rows[0];
    if (recipient) {
      emitPrivateChatMessage(savedMessage);
    } else {
      emitPublicChatMessage(savedMessage);
    }
    res.status(201).json(savedMessage);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to send message" });
  }
});

export default router;
