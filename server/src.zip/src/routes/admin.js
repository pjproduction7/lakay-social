import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { query } from "../db.js";
import { requireAuth, requireAdmin } from "./middleware/auth.js";

const router = Router();
const rawAdminUsername = process.env.ADMIN_USERNAME || process.env.VITE_ADMIN_USERNAME || "admin";
const ROOT_ADMIN_USERNAME = rawAdminUsername.trim().toLowerCase();

const createUserSchema = z.object({
  username: z.string().min(3).max(32),
  email: z
    .string()
    .email()
    .optional()
    .or(z.literal("")),
  password: z.string().min(6).max(128),
});

const passwordSchema = z.object({
  password: z.string().min(6).max(128),
});

router.use(requireAuth);
router.use(requireAdmin);

router.get("/users", async (_req, res) => {
  try {
    const result = await query(
      `SELECT u.id, u.username, u.email, u.created_at,
              p.display_name, p.bio, p.location, p.photo_url
         FROM users u
    LEFT JOIN profiles p ON p.user_id = u.id
     ORDER BY u.created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to load users" });
  }
});

router.post("/users", async (req, res) => {
  const parse = createUserSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: "Invalid request", details: parse.error.flatten().fieldErrors });
  }

  const { username, email = "", password } = parse.data;
  const normalizedUsername = username.trim().toLowerCase();
  const displayName = username.trim();
  const normalizedEmail = (email.trim() || `${normalizedUsername}@lakay.social`).toLowerCase();

  try {
    const existing = await query(
      "SELECT 1 FROM users WHERE LOWER(username) = $1 OR LOWER(email) = $2",
      [normalizedUsername, normalizedEmail]
    );
    if (existing.rowCount > 0) {
      return res.status(409).json({ error: "Username or email already exists" });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const inserted = await query(
      `INSERT INTO users (username, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, username, email, created_at`,
      [normalizedUsername, normalizedEmail, passwordHash]
    );

    await query(
      `INSERT INTO profiles (user_id, username, display_name, bio, location)
       VALUES ($1, $2, $3, '', '')
       ON CONFLICT (user_id) DO NOTHING`,
      [inserted.rows[0].id, normalizedUsername, displayName || normalizedUsername]
    );

    res.status(201).json({
      user: inserted.rows[0],
      profile: {
        username: normalizedUsername,
        displayName: displayName || normalizedUsername,
        bio: "",
        location: "",
        photoDataUrl: "",
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create user" });
  }
});

router.post("/users/:username/password", async (req, res) => {
  const parse = passwordSchema.safeParse(req.body);
  if (!parse.success) {
    return res.status(400).json({ error: "Invalid request", details: parse.error.flatten().fieldErrors });
  }

  const targetUsername = req.params.username?.trim().toLowerCase();
  if (!targetUsername) {
    return res.status(400).json({ error: "Username is required" });
  }

  try {
    const passwordHash = await bcrypt.hash(parse.data.password, 12);
    const updated = await query(
      "UPDATE users SET password_hash = $2 WHERE LOWER(username) = $1 RETURNING id, username",
      [targetUsername, passwordHash]
    );

    if (updated.rowCount === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update password" });
  }
});

router.delete("/users/:username", async (req, res) => {
  const targetUsername = req.params.username?.trim().toLowerCase();
  if (!targetUsername) {
    return res.status(400).json({ error: "Username is required" });
  }

  if (targetUsername === ROOT_ADMIN_USERNAME) {
    return res.status(400).json({ error: "Cannot delete the primary admin account" });
  }

  if (targetUsername === req.user?.username?.toLowerCase()) {
    return res.status(400).json({ error: "Cannot delete the account currently in use" });
  }

  try {
    const deleted = await query(
      "DELETE FROM users WHERE LOWER(username) = $1 RETURNING id, username",
      [targetUsername]
    );

    if (deleted.rowCount === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ success: true, user: deleted.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete user" });
  }
});

export default router;
