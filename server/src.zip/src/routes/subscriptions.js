
import express from 'express';
import { query } from '../db.js';
const router = express.Router();

// POST /subscriptions
router.post('/', async (req, res) => {
  const { userId, subscription } = req.body;
  if (!userId || !subscription) {
    return res.status(400).json({ error: 'Missing userId or subscription' });
  }
  try {
    await query(
      `INSERT INTO push_subscriptions (user_id, subscription, created_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (user_id) DO UPDATE SET subscription = EXCLUDED.subscription, created_at = NOW()`,
      [userId, JSON.stringify(subscription)]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save subscription', details: err.message });
  }
});

// GET /subscriptions/:userId
router.get('/:userId', async (req, res) => {
  const { userId } = req.params;
  try {
    const result = await query(
      'SELECT subscription FROM push_subscriptions WHERE user_id = $1',
      [userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ subscription: result.rows[0].subscription });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch subscription', details: err.message });
  }
});

export default router;
