
import express from 'express';
import { sendPushNotification } from '../services/push.js';
const router = express.Router();

// POST /api/push/send
router.post('/send', async (req, res) => {
  const { subscription, payload } = req.body;
  if (!subscription || !payload) {
    return res.status(400).json({ error: 'Missing subscription or payload' });
  }
  try {
    await sendPushNotification(subscription, payload);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send push notification', details: err.message });
  }
});

export default router;
