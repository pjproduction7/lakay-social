
import express from 'express';
import { sendEmail } from '../services/email.js';
const router = express.Router();

// POST /api/notifications/email
router.post('/email', async (req, res) => {
  const { to, subject, text, html } = req.body;
  if (!to || !subject || (!text && !html)) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    await sendEmail({ to, subject, text, html });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send email', details: err.message });
  }
});

export default router;
