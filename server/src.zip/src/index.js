import express from "express";
import cors from "cors";
import profilesRouter from "./routes/profiles.js";
import authRouter from "./routes/auth.js";

const app = express();

app.use(cors());
app.use(express.json());
// Add other middleware as needed

app.get('/', (_req, res) => {
  res.send('Lakay API server is running.');
});

app.use("/profiles", profilesRouter);
app.use("/auth", authRouter);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

export default app;


